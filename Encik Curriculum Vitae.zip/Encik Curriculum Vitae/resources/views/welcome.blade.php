<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Website CV</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp"
      crossorigin="anonymous"
    />

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <link rel="stylesheet" href="frontend/style.css" />
  </head>
  <body>
    <!--Navbar-->
    <nav
      class="navbar navbar-expand-lg fixed-top"
      style="background-color: #0077b6 "
    >
      <div class="container">
        <a class="navbar-brand" href="#">Navbar</a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="#education">Education</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="#skillAndLang">Skill</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="#organisation">Organisation</a>
              </li>
          </ul>
        </div>
      </div>
    </nav>
    <!--End Navbar-->

    <!--Jumbotron-->
    <div class="jumbotron">
      <div class="container text-center">
        <div class="row justify-content-between">
          <div data-aos="fade-right" class="col-lg-3 mukaEncik">
            <img
              src="../asset/pas foto.jpg"
              class="img-fluid"
              width="300px"
              style="
                border-radius: 50px;
                border-color: #00b4d8;
                border-width: 5px;
                border-style: solid;
              "
            />
          </div>
          <div
            class="col-lg-6 encik"
            style="display: flex; align-items: center"
          >
            <div data-aos="fade-right">
              <h1 style="font-size: 5vmax" class="text-start">
                Hi, I'm <br />
                Encik Mohammad <br />
                Habib Tara
              </h1>
              <p class="desc text-start">
                A Student from Universitas Internasional Batam
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--End Jumbotron-->

    <!--Education-->
    <div class="education" id="education">
      <div class="wrapper" data-aos="fade-up">
        <h1 class="text-center" style="margin-bottom: 40px">Education</h1>
        <ul style="font-size: 20px">
          <li>SD 005 Tanjungpinang | 2010 - 2013</li>
          <li>SD Pelita Nusantara | 2014 - 2016</li>
          <li>SMP NEGERI 4 TANJUNGPINANG | 2016 2019</li>
          <li>SMA NEGERI 4 TANJUNGPINANG | 2019-2022</li>
          <li>Universitas Internasional Batam (UIB) | 2022 - Present</li>
        </ul>
      </div>
    </div>
    <!--End Education-->

    <!--Skill and Language-->
    <div class="skillAndLang" id="skillAndLang">
      <div class="skill">
        <div class="wrapper" data-aos="zoom-in">
          <h1 style="margin-bottom: 50px">Skills</h1>

          <p>MS Word</p>
          <div
            class="progress"
            role="progressbar"
            aria-label="Basic example"
            aria-valuenow="0"
            aria-valuemin="0"
            aria-valuemax="100"
            style="margin-bottom: 20px"
          >
            <div
              class="progress-bar"
              style="width: 50%; background-color: #e384ff"
            ></div>
          </div>

          <p>MS Excel</p>
          <div
            class="progress"
            role="progressbar"
            aria-label="Basic example"
            aria-valuenow="25"
            aria-valuemin="0"
            aria-valuemax="100"
            style="margin-bottom: 20px"
          >
            <div
              class="progress-bar"
              style="width: 30%; background-color: #e384ff"
            ></div>
          </div>

          <p>Python</p>
          <div
            class="progress"
            role="progressbar"
            aria-label="Basic example"
            aria-valuenow="50"
            aria-valuemin="0"
            aria-valuemax="100"
            style="margin-bottom: 20px"
          >
            <div
              class="progress-bar"
              style="width: 50%; background-color: #e384ff"
            ></div>
          </div>
        </div>
      </div>

      <div class="language">
        <div data-aos="fade-up" class="wrapper">
          <h1>Language</h1>

          <ul style="font-size: 20px">
            <li>English - Intermediate</li>
            <li>Indonesian - Native</li>
          </ul>
        </div>
      </div>
    </div>
    <!--End Skill and Language-->

    <!--Organisation-->
    <div class="organisation" id = "organisation">
      <div class="wrapper" data-aos="fade-up">
        <h1 class = "text-center" style = "padding-bottom: 30px;">Organisation</h1>

        <ul style  ="font-size: 20px;">
          <li>OSIS (2019-2022) | Leader of Multimedia Division</li>
          <li>UKM Teater Warna | Multimedia Division</li>
          <li>UKM Grafity | Photography Division</li>
          <li>HMPS SI | Multimedia Division</li>
        </ul>
      </div>
    </div>
    <!--End Organisation-->

    <!--Footer-->
    <div class="footer">
        <div class="container text-start">
            <div class="row justify-content-between">
              <div class="col-md-4" style = "padding-bottom: 30px;">
                <div style="margin-bottom: 20px">
                  <img src="../asset/instagram.png" width="30px" />
                  <span style="font-weight: 500">@encik_mht</span>
                </div>
                <div style="margin-bottom: 20px">
                    <img src="../asset/whatsapp.png" width="30px" />
                    <span style="font-weight: 500">habibtara08@gmail.com</span>
                  </div>
                <div>
                  <img src="../asset/email.png" width="30px" />
                  <span style="font-weight: 500">0812-7691-7603</span>
                </div>
              </div class = "text-center">
              <div class="col-md-4 madeBy" style="font-weight: 500">
                2023 | encikmohammad
              </div>
            </div>
          </div>
        </div>
    </div>
     <!--End Footer-->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N"
      crossorigin="anonymous"
    ></script>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <script>
        AOS.init();
      </script>
  </body>
</html>
